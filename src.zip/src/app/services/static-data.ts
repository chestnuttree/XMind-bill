export const typeOptions = [
  { value: 0, text: '支出' },
  { value: 1, text: '收入' },
];
